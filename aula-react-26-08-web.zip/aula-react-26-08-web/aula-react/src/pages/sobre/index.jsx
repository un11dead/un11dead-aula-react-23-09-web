function Sobre(){
    return(
        <div>
        <h2>Sou um desenvolvedor em treinamento</h2>
        </div>
    )
}
export default Sobre