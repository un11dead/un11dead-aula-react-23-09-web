function Contato(){
    return(
        <div>
        <h2>Aqui você encontra meus contatos!</h2>
        </div>
    )
}
export default Contato 